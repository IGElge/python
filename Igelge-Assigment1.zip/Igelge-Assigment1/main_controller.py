#NAME:Isabella Elge
#DATE:September 4th, 2025
#PROJECT:Module 1 Assignment
#RESOURECS: I utilized the book and the slides
#PURPOSE: Prints "Hello World" on a webpage

#Imports FastAPI
from fastapi import FastAPI

#Defines the app to FastAPI
app = FastAPI()

#Calls the app to the endpoint /
@app.get("/")
#Defines the method
async def root_call():
    #Prints "Hello World"
    return {"Hello World"}
