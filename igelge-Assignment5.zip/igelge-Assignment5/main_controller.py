from fastapi import FastAPI, HTTPException
from typing import List
from models.product import Product
from models.product_request import ProductRequest
import services.product_service as product_service

app = FastAPI(
    title="Module 4 - Products API",
    version="1.0",
    contact={"name": "Isabella Elge", "email": "igelge@mail.mccneb.edu"},
    description="Assignment 4 - Products API with SQLite and Services"
)

@app.get("/")
def root():
    return {"message": "Welcome to the Products API! Go to /docs for Swagger UI."}

@app.get("/products", response_model=List[Product])
def get_products():
    return product_service.get_all_products()

@app.get("/product", response_model=Product)
def get_product(product_id: int):
    product = product_service.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

@app.post("/products/mod")
def update_product(product: ProductRequest):
    message = product_service.add_or_update_product(product)
    return {"message": message}
