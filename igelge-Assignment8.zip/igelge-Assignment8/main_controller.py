from fastapi import FastAPI, status, Header, Query, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from models.product import Product
from models.product_request import ProductRequest
import services.product_service as product_service
import services.token_service as token_service

app = FastAPI(
    title="Module 8 - Products API",
    version="1.0",
    contact={"name": "Isabella Elge", "email": "igelge@mail.mccneb.edu"},
    description="Assignment 8 - Products API with SQLite, Tokens, and Authorization Headers"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def validate_token(token: Optional[str]) -> bool:
    if not token:
        return False
    return token_service.token_exists(token)


@app.get("/", summary="Root Endpoint")
def root():
    return {"message": "Welcome to the Products API! Go to /docs for Swagger UI."}


@app.get(
    "/products",
    response_model=List[Product],
    responses={
        200: {"description": "List of all products returned"},
        400: {"description": "No products found in the database"},
        401: {"description": "Unauthorized - Invalid or missing token"},
    },
    summary="Get All Products",
    tags=["Products"],
)
def get_products(
    authorization: Optional[str] = Header(None),
    user_id: Optional[str] = Query(None)
):
    token = authorization or (user_id if user_id else None)
    if not validate_token(token):
        return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                            content={"message": "Unauthorized token, please check and then retry"})

    products = product_service.get_all_products()
    if not products:
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                            content={"message": "No products available"})
    return products


@app.get(
    "/product",
    response_model=Product,
    responses={
        200: {"description": "Product found and returned"},
        400: {"description": "Product ID not found"},
        401: {"description": "Unauthorized - Invalid or missing token"},
    },
    summary="Get Single Product by ID",
    tags=["Products"],
)
def get_product(
    product_id: Optional[int] = Query(None),
    authorization: Optional[str] = Header(None),
    user_id: Optional[str] = Query(None)
):
    token = authorization or (user_id if user_id else None)
    if not validate_token(token):
        return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                            content={"message": "Unauthorized"})

    if product_id is None:
        products = product_service.get_all_products()
        if not products:
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                                content={"message": "No products available"})
        return products

    product = product_service.get_product_by_id(product_id)
    if not product:
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                            content={"message": "Product not found"})
    return product


@app.post(
    "/products/mod",
    responses={
        200: {"description": "Product added or updated successfully"},
        400: {"description": "Invalid request object"},
        401: {"description": "Unauthorized - Invalid or missing token"},
    },
    summary="Add or Update Product",
    tags=["Products"],
)
async def update_product(
    request: Request,
    authorization: Optional[str] = Header(None),
    user_id: Optional[str] = Query(None)
):
    token = authorization or (user_id if user_id else None)
    if not validate_token(token):
        return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED,
                            content={"message": "Unauthorized"})

    body = await request.json()

    product_data = {
        "ID": body.get("ID"),
        "Name": body.get("Name") or body.get("FirstName", "Unknown"),
        "Price": float(body.get("Price") or 0.0),
        "Type": body.get("Type") or "Unknown"
    }

    if not product_data["Name"] or not product_data["Type"]:
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                            content={"message": "Request object missing required fields or invalid"})

    message = product_service.add_or_update_product(ProductRequest(**product_data))
    return {"message": message}
