#NAME: Isabella Elge
#DATE:09/24/25
#CLASS: INFO 1511
#ASSIGNMENT: Module 3 Assignment
#PURPOSE: This will print a global list of fruits and vegetables and then allow others to modify that list to display added
#product

#Import statements
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

#Prints header and information on the /docs
app = FastAPI(
    title="Module 3",
    version="1.0",
    contact={"name": "Isabella Elge", "email": "igelge@mail.mccneb.edu"},
    description="Assignment 3 - Products API"
)



# Global Product List
Products = [
    {'ID': 0, 'Name': 'Apple', 'Price': 4.99, 'Type': 'Fruit'},
    {'ID': 1, 'Name': 'Orange', 'Price': 8.99, 'Type': 'Fruit'},
    {'ID': 2, 'Name': 'Tomato', 'Price': 3.99, 'Type': 'Fruit'},
    {'ID': 3, 'Name': 'Cabbage', 'Price': 1.99, 'Type': 'Vegetable'},
    {'ID': 4, 'Name': 'Potato', 'Price': 2.50, 'Type': 'Vegetable'},
    {'ID': 5, 'Name': 'Potato', 'Price': 2.50, 'Type': 'Vegetable'}
]

# Request Object (Pydantic model)
class Product(BaseModel):
    ID: int
    Name: str
    Price: float
    Type: str

#welcome page message
@app.get("/")
def root():
    return {"message": "Welcome to the Products API! Go to /docs for Swagger UI."}

# GET /products
@app.get("/products", response_model=List[dict])
def get_products():
    return Products

# POST /products/mod
@app.post("/products/mod")
def update_product(product: Product):
    for index, existing_product in enumerate(Products):
        #sets an if statement for an identical ID and will change the existing product
        if existing_product["ID"] == product.ID:
            Products[index] = product.dict()
            return {"message": "Modified Product"}
    Products.append(product.dict())
    return {"Updated Product Successfully"}
