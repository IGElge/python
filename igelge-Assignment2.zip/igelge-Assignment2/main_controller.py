#NAME: Isabella Elge
#DATE: 9/14/25
#CLASS: INFO 1511
#ASSIGNMENT: Module 2 assignment
#RESOURCES: I utilized the book and lecture to complete this assignment

#PURPOSE: Prints products based off of cost and sorts for those that fall between a min/max

#imports tools needed to make the program run
from typing import Optional
from fastapi import FastAPI

# Start the FastAPI app
app = FastAPI()

# creates a global product list
products = [
    {'Name': 'Apple', 'Price': 4.99, 'Type': 'Fruit'},
    {'Name': 'Orange', 'Price': 8.99, 'Type': 'Fruit'},
    {'Name': 'Tomato', 'Price': 3.99, 'Type': 'Fruit'},
    {'Name': 'Cabbage', 'Price': 1.99, 'Type': 'Vegetable'},
    {'Name': 'Potato', 'Price': 2.50, 'Type': 'Vegetable'},
    {'Name': 'Potato', 'Price': 2.50, 'Type': 'Vegetable'}
]

# Root endpoint that prints a welcome message
@app.get("/")
async def root_call():
    return {"message": "Welcome to the Product API!"}

# /products endpoint with the three params (with a required price but the rest are optional)
@app.get("/products")
def get_products(
    product_price: float,
    product_type: Optional[str] = None,
    product_name: Optional[str] = None
):
    #prints the results if the product has a price
    results = [p for p in products if p['Price'] == product_price]

#sets the if for a product type and name because that is not required
    if product_type:
        results = [p for p in results if p['Type'].lower() == product_type.lower()]
    if product_name:
        results = [p for p in results if p['Name'].lower() == product_name.lower()]
#prints the results to the /products page
    return results

# /products/price endpoint with min/max ranges
@app.get("/products/price")
def get_all_products(min_price: float, max_price: float):
    return [
        p for p in products
        if min_price < p["Price"] < max_price
    ]
